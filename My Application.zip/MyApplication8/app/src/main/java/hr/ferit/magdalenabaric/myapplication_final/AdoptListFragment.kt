package hr.ferit.magdalenabaric.myapplication_final

import android.os.Bundle
import android.telecom.Call
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import com.google.android.gms.common.api.Response
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AdoptListFragment : Fragment() {
    private lateinit var adapter: Adapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var dogArrayList: ArrayList<Dog>
    private val db = Firebase.firestore
    private lateinit var recyclerAdapter: Adapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_adopt_list, container, false)
        val view2 = inflater.inflate(R.layout.fragment_adopt, container, false)
        val view3 = inflater.inflate(R.layout.fragment_adopt_buttons, container, false)

        val btnBack7= view.findViewById<Button>(R.id.btnBack7)
        val btnNext6= view.findViewById<Button>(R.id.btnNext6)
        val recyclerViewAdopt = view.findViewById<RecyclerView>(R.id.dogList)

        db.collection("projekt")
            .get()
            .addOnSuccessListener {
                val list : ArrayList<Dog> = ArrayList() //prvo loadamo sve podatke iz dokumenata i onda ih pretvaramo u nas model rucno, nije kao kod retrofita
                for(data in it.documents){
                    val person = data.toObject(Dog::class.java)
                    if ( person != null){
                        person.id = data.id  //prije dodavanja u listu, potrebno je svakom novom objektu dodati id
                        list.add(person)
                    }
                }
                recyclerAdapter = Adapter(list)
                recyclerView.apply{   //pomocu ovoga se prikazuje
                   // layoutManager = LinearLayoutManager(@this, vertical)
                    adapter =
                        recyclerAdapter
                }
            }
            .addOnFailureListener{
                Log.e("MainActivity", it.message.toString())
            }






        btnBack7.setOnClickListener {
            val sureFragment = AdoptButtonsFragment()
            //val radioButton = view.findViewById<RadioButton>(radiogroup.checkedRadioButtonId)
            val bundle= Bundle()
            //bundle.putString("button", radioButton.text.toString())
            sureFragment.arguments=bundle
            val fragmentTransaction: FragmentTransaction?=activity?.supportFragmentManager?.beginTransaction()
            fragmentTransaction?.replace(R.id.firstPage, sureFragment)
            fragmentTransaction?.commit()
        }

        btnNext6.setOnClickListener {
            val sureFragment = AdoptedFragment()
            //val radioButton = view.findViewById<RadioButton>(radiogroup.checkedRadioButtonId)
            val bundle= Bundle()
            //bundle.putString("button", radioButton.text.toString())
            sureFragment.arguments=bundle
            val fragmentTransaction: FragmentTransaction?=activity?.supportFragmentManager?.beginTransaction()
            fragmentTransaction?.replace(R.id.firstPage, sureFragment)
            fragmentTransaction?.commit()
        }

        return view

        //val view = inflater.inflate(R.layout.fragment_adopt_list, container, false)
        //val view2 = inflater.inflate(R.layout.fragment_adopt_buttons, container, false)

        //val btn=view2.findViewById<Button>(R.id.btnNext3)

        /*btn.setOnClickListener {
                super.onCreate(savedInstanceState)

                findViewById<RecyclerView>(R.id.makeupList).apply {
                layoutManager =
                    LinearLayoutManager(this@MainActivity)
                adapter =
                    MakeupAdapter(response.body()!!) //u nasem zadatku nece biti .data
            }
        }*/


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView=view.findViewById(R.id.dogList)
        recyclerView.layoutManager=LinearLayoutManager(context)
        recyclerView.setHasFixedSize(true)
        adapter=Adapter(dogArrayList)  //mozda, zagradu sam izmislila
        recyclerView.adapter=adapter
    }
}